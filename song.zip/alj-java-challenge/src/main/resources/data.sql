--Initialize the DataBase Data　
insert into employee(department, employee_name, employee_salary) values ('HR', 'ton', 1500);
insert into employee(department, employee_name, employee_salary) values ('HR', 'tom', 1500);
insert into employee(department, employee_name, employee_salary) values ('IT', 'cat', 2000);
insert into employee(department, employee_name, employee_salary) values ('IT', 'ban', 2000);